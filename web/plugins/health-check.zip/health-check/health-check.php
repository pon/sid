<?php
/*
Plugin Name: Poplar WP Health Check
*/

echo 'OK';
?>
